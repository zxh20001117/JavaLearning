package lesson3;

public class Test {
    public static void main(String[] args) {
        Person p1 = new Person("asd");
        Person p2 = p1;
        System.out.println(p2.name);
    }

}